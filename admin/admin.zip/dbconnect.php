<?php
  
		$dbHost     = 'localhost';
        $dbUsername = 'dharlitl_dharma123';
        $dbPassword = 'dharma123';
        $dbName     = 'dharlitl_dcl';
?>